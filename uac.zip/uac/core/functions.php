<?php

    require_once 'core/base.php';

    function alert($data,$color='danger'){
        return "<p class='alert alert-$color'>$data</p>";
    }

    function redirect($l){
        return header("location:$l");
    }

    function runQuery($sql){

        if(mysqli_query(con(),$sql)){
            return true;
        }else{
            die('Errors : '.$sql);
        }
    }



    function register(){
//        global $conn;
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $cpassword = $_POST['cpassword'];

        if($password == $cpassword){
            $sPass = password_hash($password,PASSWORD_DEFAULT);
            $sql = "INSERT INTO users(name,email,password) VALUES ('$name','$email','$sPass')";
            if(runQuery($sql)){
                return redirect('login.php');
            }

        }else{
            return alert('Passwords do not match!!!!');
        }
    }

    function login(){
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE email='$email'";
        $query = mysqli_query(con(),$sql);
        $row = mysqli_fetch_assoc($query);

        if(!$row){
            return alert('Email and password do not match!!!');
        }else{
            if(!password_verify($password,$row['password'])){
                return alert('Email and Password Do not match!!!');
            }else{
                session_start();
                $_SESSION['user'] = $row;
                return redirect("dashboard.php");
            }
        }

    }